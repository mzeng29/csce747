package exceptions;

public class CancelVacationException extends Exception {
	
	private static final long serialVersionUID = -6565485892997356213L;

	public CancelVacationException(String msg) {
		super(msg);
	}
}
