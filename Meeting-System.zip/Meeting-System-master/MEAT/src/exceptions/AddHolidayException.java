package exceptions;

public class AddHolidayException extends Exception {

	private static final long serialVersionUID = -6565485892997356213L;

	public AddHolidayException(String msg) {
		super(msg);
	}
}
