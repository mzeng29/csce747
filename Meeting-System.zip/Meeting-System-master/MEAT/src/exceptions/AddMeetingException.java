package exceptions;

public class AddMeetingException extends Exception {
	
	private static final long serialVersionUID = -6565485892997356213L;

	public AddMeetingException(String msg) {
		super(msg);
	}
}
