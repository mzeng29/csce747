package exceptions;

public class PrintScheduleRoomException extends Exception {

	
	private static final long serialVersionUID = -6565485892997356213L;

	public PrintScheduleRoomException(String msg) {
		super(msg);
	}
	
}
