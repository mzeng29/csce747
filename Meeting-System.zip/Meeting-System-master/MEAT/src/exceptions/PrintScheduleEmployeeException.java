package exceptions;

public class PrintScheduleEmployeeException extends Exception {

	
	private static final long serialVersionUID = -6565485892997356213L;

	public PrintScheduleEmployeeException(String msg) {
		super(msg);
	}
}
