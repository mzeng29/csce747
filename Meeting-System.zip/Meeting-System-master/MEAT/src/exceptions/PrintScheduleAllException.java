package exceptions;

public class PrintScheduleAllException extends Exception {
	private static final long serialVersionUID = -6565485892997356213L;

	public PrintScheduleAllException(String msg) {
		super(msg);
	}
}
